﻿using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.PW.MetaDataModel.Services;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Models.DataTables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.PW.MetaDataModel.Controllers;

public partial class SourceTablesSAPSystemPluginController : BasePluginController
{
    private readonly ISourceTablesSAPSystemService _service;
    public SourceTablesSAPSystemPluginController(ISourceTablesSAPSystemService service)
    {
        _service = service;
    }

    [HttpGet]
    public IActionResult Configure()
    {
        CustomersByCountrySearchModel customerSearchModel = new CustomersByCountrySearchModel
        {
            AvailablePageSizes = "10"
        };
        return View("~/Plugins/Tutorial.DistOfCustByCountry/Views/Configure.cshtml", customerSearchModel);
    }

    [HttpPost]
    public async Task<IActionResult> GetSourceTablesSAPSystem()
    {
        try
        {
            return Ok(new DataTablesModel { Data =  _service.GetSourceTablesSAPSystemAsync() });
        }
        catch (Exception ex)
        {
            return BadRequest(ex);
        }
    }
}
