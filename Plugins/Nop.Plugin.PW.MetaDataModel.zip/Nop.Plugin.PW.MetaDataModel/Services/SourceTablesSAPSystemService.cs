﻿using Nop.Data;
using Nop.Plugin.PW.MetaDataModel.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.PW.MetaDataModel.Services;


public interface ISourceTablesSAPSystemService
{
    /// <summary>
    /// Logs the specified record.
    /// </summary>
    /// <param name="record">The record.</param>
    void Log(SourceTablesSAPSystem record);
    List<SourceTablesSAPSystem> GetSourceTablesSAPSystemAsync();
}


public class SourceTablesSAPSystemService : ISourceTablesSAPSystemService
{
    private readonly IRepository<SourceTablesSAPSystem> _sourceTablesSAPSystemRecordRepository;
    public SourceTablesSAPSystemService(IRepository<SourceTablesSAPSystem> sourceTablesSAPSystemRecordRepository)
    {
        _sourceTablesSAPSystemRecordRepository = sourceTablesSAPSystemRecordRepository;
    }

    public  List<SourceTablesSAPSystem> GetSourceTablesSAPSystemAsync()
    {
        return (List<SourceTablesSAPSystem>)_sourceTablesSAPSystemRecordRepository.GetAll();
    }

    /// <summary>
    /// Logs the specified record.
    /// </summary>
    /// <param name="record">The record.</param>
    public virtual void Log(SourceTablesSAPSystem record)
    {
        if (record == null)
            throw new ArgumentNullException(nameof(record));
        _sourceTablesSAPSystemRecordRepository.Insert(record);
    }
}

