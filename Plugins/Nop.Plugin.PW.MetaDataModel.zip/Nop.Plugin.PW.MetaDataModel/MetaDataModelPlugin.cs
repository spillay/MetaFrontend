﻿using Nop.Plugin.PW.MetaDataModel.Components;
using Nop.Services.Cms;
using Nop.Services.Plugins;
using Nop.Web.Framework.Infrastructure;

namespace Nop.Plugin.PW.MetaDataModel
{
    /// <summary>
    /// Rename this file and change to the correct type
    /// </summary>
    public class MetaDataModelPlugin : BasePlugin, IWidgetPlugin
    {
        bool IWidgetPlugin.HideInWidgetList => false;

        Type IWidgetPlugin.GetWidgetViewComponent(string widgetZone)
        {
            return typeof(SourceTablesSAPSystemViewComponent);
        }

        Task<IList<string>> IWidgetPlugin.GetWidgetZonesAsync()
        {
            //return Task.FromResult<IList<string>>(new List<string> { PublicWidgetZones.ProductDetailsTop });
            return Task.FromResult<IList<string>>(new List<string> { "home_page_before_categories" });
        }
    }
}