﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.PW.MetaDataModel.Domains;
using Nop.Plugin.PW.MetaDataModel.Services;
using Nop.Services.Catalog;
using Nop.Services.Customers;
using Nop.Web.Framework.Components;
using Nop.Web.Models.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.PW.MetaDataModel.Components;

public partial class SourceTablesSAPSystemViewComponent : NopViewComponent
{
    private readonly ICustomerService _customerService;
    private readonly IProductService _productService;
    private readonly ISourceTablesSAPSystemService _sourceTablesSAPSystemService;
    private readonly IWorkContext _workContext;
    public SourceTablesSAPSystemViewComponent(ICustomerService customerService,
        IProductService productService,
        ISourceTablesSAPSystemService sourceTablesSAPSystemService,
        IWorkContext workContext)
    {
        _customerService = customerService;
        _productService = productService;
        _sourceTablesSAPSystemService = sourceTablesSAPSystemService;
        _workContext = workContext;
    }
    public async Task<IViewComponentResult> InvokeAsync(string widgetZone, object additionalData)
    {
        //if (!(additionalData is ProductDetailsModel model))
        //    return Content("");
        ////Read from the product service
        //var productById = await _productService.GetProductByIdAsync(model.Id);
        ////If the product exists we will log it
        //if (productById != null)
        //{
        //    var currentCustomer = await _workContext.GetCurrentCustomerAsync(); //.CurrentCustomerAsync();
        //    //Setup the product to save
        //    var record = new SourceTablesSAPSystem
        //    {
        //        ID = model.Id,
        //        Name = model.Name
        //        //CustomerId = currentCustomer.Id,
        //        //IpAddress = currentCustomer.LastIpAddress,
        //        //IsRegistered = await _customerService.Async(currentCustomer)
        //    };
        //    //Map the values we're interested in to our new entity
        //    _sourceTablesSAPSystemService.Log(record);
        //}
        return Content("SourceTables Log");
    }
}
